


class IfElseDemo{
	public static void main(String[] args) {
		boolean myVar = true;

		if(myVar) // result should be a boolean
			System.out.println("YES");
		System.out.println("NO");

	}
}


// if(condtion){ < <= > >= == !=
// 			stmt/s
// 		}


// true - true
// false - false


