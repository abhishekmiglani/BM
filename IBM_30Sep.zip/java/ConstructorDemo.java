	
	// Constructors


	class A{
		 A(){
		 	System.out.println("Inside A...");
		}
	}


	class ConstructorDemo{
		public static void main(String[] args) {
			A a = new A();
		}
	}

