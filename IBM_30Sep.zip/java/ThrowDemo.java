

class ThrowDemo{
	void someWork() throws Exception{


		if(somethingGoesTerriblyWrong){

			throw new Exception();

		}



	}
}