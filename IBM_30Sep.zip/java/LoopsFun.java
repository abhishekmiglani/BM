class LoopsFun{
	public static void main(String[] args) {
		//int var;
		// for (var = 27; var > 21;var -=2) {
		// 	System.out.println(var);
		// }

		// var = 27;
		// while(var > 21){
		// 	System.out.println(var);
		// 	var -=2;
		// }

		// java.util.Scanner scan = new java.util.Scanner(System.in);

		// System.out.println("Enter any number");
		// int num = scan.nextInt();
		// int other;

		// for(;num > 0;){
		// 	other = num % 10;
		// 	num = num / 10;
		// 	System.out.print(other);
		// }

		// OR

		// while(num > 0){
		// 	other = num % 10;
		// 	num = num / 10;
		// 	System.out.print(other);
		// }

		// int var = 7;
		// do{
		// 	System.out.println("\n" + var);
		// 	var++;
		// }while(var > 45);

		System.out.print("Hello there how are you doing\r");
		System.out.print("I am doing great...");




	}
}