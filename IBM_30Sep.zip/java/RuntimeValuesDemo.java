class RuntimeValuesDemo{
	public static void main(String[] args) {
		
		int firstNum = Integer.parseInt(args[0]);
		int secondNum = Integer.parseInt(args[1]);

		int result = firstNum + secondNum;

		System.out.println("Addtiton of no's is: " + result);
	}
}