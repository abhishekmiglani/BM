class VariablesLevelDemo{
	boolean flag;
	int f;
	VariablesLevelDemo ref;

	public static void main(String[] args) {
		// int var = 0;
		// VariablesLevelDemo ob = new VariablesLevelDemo();
		// VariablesLevelDemo ob2 = new VariablesLevelDemo();
		// ob.f = 654;
		// System.out.println(ob2.f);

		// System.out.println(var); 

		for(int v = 10; v < 5;v++){
			System.out.println(v);
		}
		// System.out.println(v); // Error

}

void func(){
	// var = 90; // Error
	VariablesLevelDemo r;
	byte br;
}

}

	// boolean - false
	// short
	// byte
	// int
	// long ---- 0

	// float
	// double -- 0.0



	// null










