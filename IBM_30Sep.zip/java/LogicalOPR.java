class LogicalOPR{
	public static void main(String[] args) {
		// &&, &, ||, |, !, ^

		boolean flag = false;

		int a =90, b = 7;

		if(a < 10 & flag = true){
			System.out.println("YES");
		}
		else{
			System.out.println("NO");
		}
	}
}