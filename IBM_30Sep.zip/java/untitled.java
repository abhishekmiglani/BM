class GCTest{
	public static void main(String[] args) {
		
		Runtime ref = Runtime.getRuntime();

System.out.println("Total Memory : " + ref.totalMemory());
System.out.println("Free Memory : " + ref.freeMemory());



	}
}