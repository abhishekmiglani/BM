

// Methods 

// 	Scope returnType identifier(ParameterList){
// 		Stmt/s
// 	}

class MethodDemo{
	public static void main(String[] args) {
		new MethodDemo().func();

	}

	void func(){
		System.out.println("Inside func()...");
	}
}

a --Message/s----> b
  <--Message----