package mayank;

public class My{

	private long var;

	protected void met(){
		System.out.println("Inside met...");
	}
}