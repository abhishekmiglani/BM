class GCDemo{
	static GCDemo t;
	public static void main(String[] args) {
		
		GCDemo a = new GCDemo();
		GCDemo b = new GCDemo();
		GCDemo c = new GCDemo();

		a.t = b; //GCDemo.t = b;
		b.t = c; //GCDemo.t = c;
		c.t = a; //GCDemo.t = a;

		a = b = c = null;

		// 


	}

	void doSomething(){

		GCDemo temp = new GCDemo();

		temp.d = 653.33;

		System.out.println(temp.d);
	}
}


// ref ---------> Object

// 				 Object

