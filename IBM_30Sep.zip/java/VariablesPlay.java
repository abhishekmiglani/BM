class VariablesPlay{
	public static void main(String[] args) {
		float var = 78.89F;

		double value = var;

		System.out.println("Value of variable is : " + value);
	}
}