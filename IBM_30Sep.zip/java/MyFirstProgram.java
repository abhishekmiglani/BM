
class MyFirstProgram{
	public static void main(String[] args) {
	// System.out.println("We are just starting with JAVA...");	
	// System.out.println("On the next line...");	

		// DataType identifier;

		boolean var;

		// identifier = value;

		var = false;

		System.out.println("Value of variable is :" + var);
		// System.out.println(var);



	}
	
}


	// boolean - 1
	// byte - 1
	// short - 2
	// char - 2
	// int - 4
	// long - 8
	// float - 4
	// double - 8








